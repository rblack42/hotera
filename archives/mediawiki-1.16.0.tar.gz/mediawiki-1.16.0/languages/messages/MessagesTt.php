<?php
/** Tatar (Tatarça/Татарча)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @comment Placeholder for Tatar. Falls back to Tatar in Latin script.
 */

$fallback = 'tt-cyrl';
