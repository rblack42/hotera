<?php
/** English
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment dummy language file. Falls back to 'en'. Needed for http://simple.wikipedia.org.
 */

$fallback = 'en';
